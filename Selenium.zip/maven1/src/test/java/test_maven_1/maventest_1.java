package test_maven_1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class maventest_1 {
  @Test
  public void f() {
	  String ar = "hello", er="hello";
	  Assert.assertEquals(ar, er);
  }
}
