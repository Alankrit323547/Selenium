package Day5;

import org.openqa.selenium.WebDriver;

public class Web_alert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch_browser lb = new launch_browser();
		WebDriver driver = lb.launch_chrome("http://demo.guru99.com/test/delete_customer.php");
		alerts al = new alerts();
		al.check_alert(driver);
	}
	
}
