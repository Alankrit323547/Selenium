package Day5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class NewTest_2 {
	WebDriver dr;
	String ar,er;
	login lt = new login();
	@BeforeMethod
	public void bm()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	}
  @Test
  public void test1() {
	 er = "jasonroy@gmail.com";
	  ar = lt.login_test(dr, "jasonroy@gmail.com", "england");
	  Assert.assertEquals(ar, er);
  }
  @Test
  public void test2() {
	  er = "Please enter a valid email address.";
	  ar = lt.login_test(dr, "jasonroy", "england");
	  Assert.assertEquals(ar, er);
	  
  }
  @Test
  public void test3() {
	  er = "Login was unsuccessful. Please correct the errors and try again.\n" + 
		  		"No customer account found";
		  ar = lt.login_test(dr, "jason@gmail.com", "england");
		  Assert.assertEquals(ar, er);
  }
  @AfterMethod
  public void am()
  {
	  dr.quit();
  }
}
