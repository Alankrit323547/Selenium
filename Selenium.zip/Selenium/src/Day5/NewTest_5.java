package Day5;

import org.testng.annotations.Test;

public class NewTest_5 {
  @Test
  public void h() {
	  System.out.println("3");
  }
  @Test
  public void g() {
	  System.out.println("4");
  }
}
