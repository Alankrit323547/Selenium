package Day5;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest_1 {
  @Test
  public void tc1() {
	  launch_browser lb = new launch_browser();
	  WebDriver dr = lb.launch_chrome("http://demowebshop.tricentis.com/login");
	  login lt = new login();
	  String ar = lt.login_test(dr, "jasonroy@gmail.com", "england");
	  String er = "jasonroy@gmail.com";
	  Assert.assertEquals(ar, er);
  }
  @Test
  public void tc2() {
	  launch_browser lb = new launch_browser();
	  WebDriver dr = lb.launch_chrome("http://demowebshop.tricentis.com/login");
	  login lt = new login();
	  String ar = lt.login_test(dr, "jasonroy@gmail.com", "england");
	  String er = "jason@gmail.com";
	  Assert.assertEquals(ar, er);
  }
}
