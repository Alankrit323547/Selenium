package Day5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class launch_browser {
	public WebDriver launch_chrome(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get(url);
		return dr;
	}
	public WebDriver launch_firefox(String url)
	{
		System.setProperty("webdriver.gecko.driver", "D:\\drivers\\geckodriver.exe");
		WebDriver dr = new FirefoxDriver();
		dr.get(url);
		return dr;
	}
	public WebDriver launch_ie(String url)
	{
		System.setProperty("webdriver.ie.driver", "D:\\drivers\\IEDriverServer.exe");
		WebDriver dr = new InternetExplorerDriver();
		dr.get(url);
		return dr;
	}
}
