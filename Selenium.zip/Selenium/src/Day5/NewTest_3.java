package Day5;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest_3 {
  @Test
  public void f() {
	  String er = "NOIDA", ar="NOID";
	  System.out.println("in f");
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ar, er);
	  System.out.println("in f after assert");
	  sa.assertAll();
  }
}
