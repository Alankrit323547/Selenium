package Day5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login {
	String text;
	public String login_test(WebDriver dr,String email, String pass)
	{
		dr.findElement(By.name("Email")).sendKeys(email);
		dr.findElement(By.name("Password")).sendKeys(pass);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		if(dr.getTitle().compareTo("Demo Web Shop")==0)
			text = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		else if(dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span")).isDisplayed())
			text=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span")).getText();
		else if(dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).isDisplayed())
			text= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
		return text;
	}
}
