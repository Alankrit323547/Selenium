package Day5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class alerts {
	public void check_alert(WebDriver driver)
	{
		driver.findElement(By.name("cusid")).sendKeys("alankrit");
	    driver.findElement(By.name("submit")).click();
	    driver.switchTo().alert().accept();
	    driver.switchTo().alert().accept();
	}
}
