package Day5;

import org.testng.annotations.Test;

public class NewTest_4 {
  @Test
  public void f() {
	  System.out.println("1");
  }
  @Test
  public void g() {
	  System.out.println("2");
  }
}
