package Day7;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

public class test_log {
	Logger log;
  @Test
  public void test1() {
	  System.out.println("hello");
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("test1 executed");
  }
  @Test
  public void test2() {
	  System.out.println("world");
	  log=Logger.getLogger("devpinoyLogger");
	  log.info("test2 executed");
  }
}
