package Day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class fb_login_page {
	By uname = By.xpath("//*[@id=\"email\"]");
	By pwd = By.xpath("//*[@id=\"pass\"]");
	By sb_btn = By.xpath("//*[@id='loginbutton']");
	WebDriver dr;
	
	public fb_login_page(WebDriver dr)
	{
		this.dr=dr;
	}
	public void set_uname(String email)
	{
		dr.findElement(uname).sendKeys(email);
	}
	public void set_pwd(String pass)
	{
		dr.findElement(pwd).sendKeys(pass);
	}
	public void click_submit()
	{
		dr.findElement(sb_btn).click();
	}
	public void login(String email, String pass)
	{
		this.set_uname(email);
		this.set_pwd(pass);
		this.click_submit();
	}
	public String return_title()
	{
		return dr.getTitle();
	}
}
