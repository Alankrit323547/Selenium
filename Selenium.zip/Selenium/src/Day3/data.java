package Day3;

public class data {
	String email;
	String pass;
	String exp_value;
	String act_value;
	String test_res;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getExp_value() {
		return exp_value;
	}
	public void setExp_value(String exp_value) {
		this.exp_value = exp_value;
	}
	public String getAct_value() {
		return act_value;
	}
	public void setAct_value(String act_value) {
		this.act_value = act_value;
	}
	public String getTest_res() {
		return test_res;
	}
	public void setTest_res(String test_res) {
		this.test_res = test_res;
	}
	
}
