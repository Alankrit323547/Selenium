package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float sum=0f,price[]=new float[10];
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String title = dr.getTitle();
		String exp_title = "Online Bookstore";
		if(title.compareTo(exp_title)==0)
			System.out.println("TITLE VERIFIED");
		else
			System.out.println("TITLE NOT VERIFIED");
		
		String exp_text = new String();
		for(int i=1;i<=3;i++)
		{
			if(i==1)
				exp_text="Databases";
			else if(i==2)
				exp_text="Programming";
			else if(i==3)
				exp_text="HTML & Web design";
			WebElement we1 = dr.findElement(By.name("category_id"));
			Select sel1 = new Select(we1);
			sel1.selectByVisibleText(exp_text);
			dr.findElement(By.name("DoSearch")).click();
			dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
			String text = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
			if(text.compareTo(exp_text)==0)
				System.out.println("TEXT VERIFIED");
			else
				System.out.println("TEXT NOT VERIFIED");
			String price_text = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText();
			price[i-1] = Float.parseFloat(price_text.substring(8, price_text.length()))*i;
			dr.findElement(By.name("quantity")).clear();
			dr.findElement(By.name("quantity")).sendKeys(""+i+"");
			dr.findElement(By.name("Insert1")).click();
			sum=sum+price[i-1];
			dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
			
			
		}
		System.out.println(sum);
	}

}
