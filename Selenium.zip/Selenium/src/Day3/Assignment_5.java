package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String title = dr.getTitle();
		String exp_title = "Online Bookstore";
		if(title.compareTo(exp_title)==0)
			System.out.println("TITLE VERIFIED");
		else
			System.out.println("TITLE NOT VERIFIED");
		WebElement we1 = dr.findElement(By.name("category_id"));
		Select sel1 = new Select(we1);
		sel1.selectByVisibleText("Databases");
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.xpath("//a[text()='Web Database Development']")).click();
		String text = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		String exp_text = "Web Database Development";
		if(text.compareTo(exp_text)==0)
			System.out.println("TEXT VERIFIED");
		else
			System.out.println("TEXT NOT VERIFIED");
		String price_text = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText();
		float price = Float.parseFloat(price_text.substring(8, price_text.length()));
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("2");
		dr.findElement(By.name("Insert1")).click();
		String pr = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText();
		pr=pr.substring(1, pr.length());
		float total_price = Float.parseFloat(pr);
		if(total_price==2f*price)
			System.out.println("PRICE VERIFIED");
		else
			System.out.println("PRICE NOT VERIFIED");
	}

}
