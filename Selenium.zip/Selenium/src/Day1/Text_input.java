package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Text_input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		//Email Id and password input
		dr.findElement(By.id("email")).sendKeys("girishindia95@gmail.com");
		dr.findElement(By.id("pass")).sendKeys("newfbp@55");
		dr.findElement(By.id("loginbutton")).click();
	}

}
