package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CSS_Selectors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		//CSS Selectors (following example) and XPATH creation
		dr.findElement(By.xpath("//input[@name='firstname']//following::input[1]")).sendKeys("Happy");
		dr.findElement(By.cssSelector("input[type='submit']")).click();
	}
}