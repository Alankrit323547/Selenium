package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		//Date of birth selection
		WebElement we1 = dr.findElement(By.id("day"));
		WebElement we2 = dr.findElement(By.id("month"));
		Select sel1 = new Select(we1);
		Select sel2 = new Select(we2);
		sel1.selectByVisibleText("10");
		sel2.selectByVisibleText("Apr");
	}

}
