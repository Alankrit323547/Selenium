package Day6;

import java.util.ArrayList;

public class kwdfw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<data> steps = new ArrayList<data>();
		all_functions obj = new all_functions();
		data d = new data();
		for(int i=1;i<6;i++)
		{
			d=obj.read_excel(i,"Sheet1");
			switch(d.keyword)
			{
			case "launch_browser":
				obj.launch_browser(d.test_data);
				break;
				
			case "enter_txt":
				obj.enter_txt(d.xp,d.test_data);
				break;
				
			case "click":
				obj.click(d.xp);
				break;
				
			case "verify":
				obj.write_excel(i,"Sheet1",obj.verify(d.xp, d.test_data));
				break;
			}
			steps.add(d);
		}
	}

}
