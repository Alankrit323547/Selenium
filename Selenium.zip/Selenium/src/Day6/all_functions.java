package Day6;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class all_functions {
	WebDriver dr;
	public void launch_browser(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get(url);
	}
	public void enter_txt(String xpath, String data)
	{
		dr.findElement(By.xpath(xpath)).sendKeys(data);
	}
	public void click(String xpath)
	{
		dr.findElement(By.xpath(xpath)).click();
	}
	public String verify(String xpath, String er)
	{
		String ar = dr.findElement(By.xpath(xpath)).getText();
		if(ar.compareTo(er)==0)
			return "PASS";
		return "FAIL";
	}
	public data read_excel(int i, String sheet)
	{
		data d = new data();
		try {
			File f = new File("C:\\Users\\alankrit.bamrara\\Desktop\\Excel\\kwdfw.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(i);
			XSSFCell cell_ua = row.getCell(0);
			XSSFCell cell_kw = row.getCell(1);
			XSSFCell cell_xp = row.getCell(2);
			XSSFCell cell_td = row.getCell(3);
			try
			{d.user_action = cell_ua.getStringCellValue();}
			catch(Exception e) {d.user_action=" ";}
			try
			{d.keyword = cell_kw.getStringCellValue();}
			catch(Exception e) {d.keyword=" ";}
			try
			{d.xp = cell_xp.getStringCellValue();}
			catch(Exception e) {d.xp=" ";}
			try
			{d.test_data = cell_td.getStringCellValue();}
			catch(Exception e) {d.test_data=" ";}
			wb.close();
			return d;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
	}
	public void write_excel(int i, String sheet, String res)
	{
		try {
			File f = new File("C:\\Users\\alankrit.bamrara\\Desktop\\Excel\\kwdfw.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(i);
			XSSFCell cell = row.createCell(4);
			cell.setCellValue(res);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
