package Day6;

public class data {
	String user_action;
	String keyword;
	String xp;
	String test_data;
	String test_result;
	public String getUser_action() {
		return user_action;
	}
	public void setUser_action(String user_action) {
		this.user_action = user_action;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getXp() {
		return xp;
	}
	public void setXp(String xp) {
		this.xp = xp;
	}
	public String getTest_data() {
		return test_data;
	}
	public void setTest_data(String test_data) {
		this.test_data = test_data;
	}
	public String getTest_result() {
		return test_result;
	}
	public void setTest_result(String test_result) {
		this.test_result = test_result;
	}
}
