package Day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class test_differentbrowsers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		dr.close();
		
		System.setProperty("webdriver.ie.driver", "D:\\drivers\\IEDriverServer.exe");
		WebDriver dr_ie = new InternetExplorerDriver();
		dr_ie.get("https://www.facebook.com");
		dr_ie.close();
		
		System.setProperty("webdriver.gecko.driver", "D:\\drivers\\geckodriver.exe");
		WebDriver dr_fr = new FirefoxDriver();
		dr_fr.get("https://www.facebook.com");
		dr_fr.close();
	}

}
