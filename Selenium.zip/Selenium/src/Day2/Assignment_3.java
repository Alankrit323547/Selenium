package Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//*[@class='ico-login']")).click();
		String email="jasonroy@gmail.com";
		String pass="england";
		dr.findElement(By.name("Email")).sendKeys(email);
		dr.findElement(By.name("Password")).sendKeys(pass);
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		String act_email=dr.findElement(By.xpath("//*[@class='account']")).getText();
		if(email.compareTo(act_email)==0)
			System.out.println("PASS");
		else
			System.out.println("FAIL");
	}

}
