package Day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("//*[@class='ico-register']")).click();
		String exp_title="Demo Web Shop. Register";
		String act_title = dr.getTitle();
		if(exp_title.compareTo(act_title)==0)
			System.out.println("pass");
		else
			System.out.println("fail");
		List<WebElement> rb = dr.findElements(By.name("Gender"));
		rb.get(0).click();
		dr.findElement(By.name("Email")).sendKeys("jasonroy@gmail.com");
		dr.findElement(By.name("FirstName")).sendKeys("Jason");
		dr.findElement(By.name("LastName")).sendKeys("Roy");
		dr.findElement(By.name("Password")).sendKeys("england");
		dr.findElement(By.name("ConfirmPassword")).sendKeys("england");
		dr.findElement(By.id("register-button")).click();
		dr.findElement(By.xpath("//*[@class='ico-logout']")).click();
		dr.close();
	}

}
