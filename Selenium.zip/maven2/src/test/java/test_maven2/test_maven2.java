package test_maven2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class test_maven2 {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver_v75.exe");
	  WebDriver dr = new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/login");
	  String ar = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	  String er = "Register";
	  Assert.assertEquals(ar, er);
  }
}
